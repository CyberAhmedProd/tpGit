#
# les tests!
#

from lib import ecrire, ecrireXFois


# test de ecrire()
print "-> Test ecrire: devrait ecrire une fois 'test'"
ecrire("test")


# test de ecrireXFois()
print "-> Test ecrireXFois: devrait ecrire 3 fois 'test'"
ecrireXFois(3, "test");

