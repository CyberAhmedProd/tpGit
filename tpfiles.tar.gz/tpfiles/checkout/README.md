# Démo git checkout

Programme qui dit bonjour une ou plusieurs fois

Usage: python hello.py nbfois message

nbfois : nombre de répétitions
message : message à afficher

 --help ou -h: affiche cet aide

