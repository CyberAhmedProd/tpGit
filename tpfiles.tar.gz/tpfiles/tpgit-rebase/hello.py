def ecrireXFois(x, chaine):
    for i in range(x):
        ecrire(chaine)

def ecrire(chaine):
    print chaine.upper()

ecrire("Hello world!")
