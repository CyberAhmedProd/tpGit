def ecrire(chaine):
    print chaine

ecrire("Hello world!")
