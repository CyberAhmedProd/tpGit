Doc sur la demo GIT
