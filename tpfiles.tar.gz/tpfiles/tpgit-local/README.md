Doc sur la demo GIT

On va faire mieux!
On procède à une refonte totale du projet.

Finalement, on garde  quand même hello.py...
