#include <stdio.h>
#include <stdlib.h>

const char *TITLE = "TP Git";

void display(char *msg)
{
	printf("%s. %s\n", TITLE, msg);
}

int main(int argc, char *argv[])
{
	display("Exemple de changement d'historique.");
	display("Test du remisage.");
	return EXIT_SUCCESS;
}
